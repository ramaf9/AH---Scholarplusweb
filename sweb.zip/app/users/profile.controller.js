angular.module('myApp')
	.controller('ProfileCtrl', function($state) {
		// var profileCtrl = this;
		// profileCtrl.profile = profile;
		// profileCtrl.updateProfile = function(){
	 //  		profileCtrl.profile.emailHash = md5.createHash(auth.password.email);
	 //  		profileCtrl.profile.$save().then(function(){
	    // 		$state.go('channels');
	 //  		});
		// };
	});
