app.controller('CatalogsCtrl', function($scope,$modal,$log, Product, ngProgress, toaster) {

$scope.product = new Product();
var count = 0;
function refresh() {
  // [START my_top_posts_query]
  var myUserId = firebase.auth().currentUser.uid;
  // var topUserPostsRef = firebase.database().ref('user-posts/' + myUserId).orderByChild('starCount');
  var listBeasiswa = firebase.database().ref('beasiswa').orderByChild('startdate');
  // [END my_top_posts_query]
  // [START recent_posts_query]
  var recentPostsRef = firebase.database().ref('posts').limitToLast(100);
  // [END recent_posts_query]
  var userPostsRef = firebase.database().ref('user-posts/' + myUserId);

  var fetchPosts = function(postsRef) {
    postsRef.once('value', function(snapshot) {
        $scope.$apply(function() {
          $scope.products = snapshot.val();

        });

    });
  };

//   fetchPosts(topUserPostsRef);
//   fetchPosts(recentPostsRef);
  fetchPosts(listBeasiswa);
}

  $scope.animationsEnabled = true;
  $scope.remove = function(product) {
  if(confirm("Are you sure to remove the product")){
    product.$delete(function(){
      refresh();
    });
    }
  };
  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      refresh();

    } else {
    }
  });
  $scope.open = function (p,size) {

    var modalInstance = $modal.open({
      templateUrl: 'partials/Edit.html',
      controller: 'productEditCtrl',
      size: size,
      backdrop:'static',
      resolve: {
        item: function () {
          return p;
        }
      }
    });

    modalInstance.result.then(function (selectedObject) {
      refresh();
      if(selectedObject.save == "insert"){
                //$scope.products.push(selectedObject);
                // $scope.products = $filter('orderBy')($scope.products, '_id', 'reverse');
            }else if(selectedObject.save == "update"){
                // p.year = selectedObject.name;
                // p.month = selectedObject.month;
                // p.demand = selectedObject.demand;
                // p.forecast = selectedObject.forecast;

            }

    }, function () {

      $log.info('Modal dismissed at: ' + new Date());
    });
  };


})
app.controller('LoginCtrl', function ($scope) {
    function writeUserData(userId, name, email) {
      firebase.database().ref('users/' + userId).set({
        username: name,
        email: email
      });
    }



    var signInButton = document.getElementById('sign-in-button');
    signInButton.addEventListener('click', function() {
      var provider = new firebase.auth.GoogleAuthProvider();
      firebase.auth().signInWithPopup(provider);



    });

    firebase.auth().onAuthStateChanged(function(user) {
      if (user) {
        writeUserData(user.uid, user.displayName, user.email);
        startDatabaseQueries();

      } else {
      }
    });

})

app.controller('productEditCtrl', function ($scope,item,Product, $modalInstance,ngProgress) {



    $scope.product = angular.copy(item);
    $scope.buttonText = (item._id != null) ? 'Update File' : 'Upload';
    $scope.persyaratan = [{id: 'syarat1'}, {id: 'syarat2'}];
    $scope.berkas = [{id: 'berkas1'}, {id: 'berkas2'}];

    $scope.addNewChoice = function(pil) {
      var newItemNo = $scope.persyaratan.length+1;
      pil.push({'id':'choice'+newItemNo});
    };

    $scope.removeChoice = function(pil) {
      var lastItem = $scope.persyaratan.length-1;
      if ($scope.persyaratan.length > 1) {
      $scope.persyaratan.splice(lastItem);
      }

    };

    $scope.ok = function (product,persyaratan,berkas) {
      
      ngProgress.start();
            if(product._id != null){
              product.$update(function(){

                var x = angular.copy(product);
                x.save = 'update';
                $modalInstance.close(x);
              });

            }else{
            //   Product.save(product,function(product){
                var x = angular.copy(product);
                x.save = "insert";
                var file = product.photopath;
                var newPostKey = firebase.database().ref('beasiswa').push().key;

                var metadata = {
                  'contentType': file.type
                };

                // Push to child path.
                var uploadTask = firebase.storage().ref().child('beasiswa/'+newPostKey).put(file, metadata);

                // Listen for errors and completion of the upload.
                // [START oncomplete]
                uploadTask.on('state_changed', null, function(error) {
                  // [START onfailure]
                  console.error('Upload failed:', error);
                  // [END onfailure]
                }, function() {
                  
                  var url = uploadTask.snapshot.metadata.downloadURLs[0];
                  
                  // [START_EXCLUDE]
                  product.photopath = url;
                  product.persyaratan = {
                    kuantitatif:{
                      ipk : persyaratan.kuantitatif.ipk,
                      semester : persyaratan.kuantitatif.semester,
                      bidang : persyaratan.kuantitatif.bidang

                    },
                    kualitatif:persyaratan.kualitatif
                    }
                product.berkas = berkas.name;
                
                
                firebase.database().ref('beasiswa/'+newPostKey).set(product);
                

                 $modalInstance.close(x);
                  // [END_EXCLUDE]
                });


                
            //   });

            }

    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
    };

    /*DATEPICKER*/

         /*DATEPICKER DONE*/

  })
