app.controller('AdminCtrl', function($scope) {

});
